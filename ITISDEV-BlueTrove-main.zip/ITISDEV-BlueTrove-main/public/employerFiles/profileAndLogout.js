document.addEventListener('DOMContentLoaded', () => {
    // View Profile button action
    document.getElementById('view-profile-btn').addEventListener('click', async () => {
        try {
            const response = await fetch('/api/current-user');
            if (response.ok) {
                const user = await response.json();
                window.location.href = `/employerFiles/userprofile.html?data=${encodeURIComponent(JSON.stringify(user))}`;
            } else {
                const errorData = await response.json();
                console.error('Failed to fetch user data:', errorData);
                alert(`Failed to fetch user data: ${errorData.error}`);
            }
        } catch (error) {
            console.error('Error fetching user data:', error);
            alert(`Error fetching user data: ${error.message}`);
        }
    });

    // Logout button action
    document.getElementById('logout-btn').addEventListener('click', async () => {
        try {
            const response = await fetch('/logout', { method: 'POST' });
            if (response.ok) {
                window.location.href = '/employerFiles/homepage.html';
            } else {
                alert('Failed to log out');
            }
        } catch (error) {
            console.error('Error during logout:', error);
            alert('Error logging out');
        }
    });
});