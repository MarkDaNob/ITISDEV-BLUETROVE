document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const jobId = urlParams.get('id');

    if (!jobId) {
        document.getElementById('job-details').innerHTML = 'Job ID is missing.';
        return;
    }

    try {
        const response = await fetch(`/api/jobs/${jobId}`);
        if (!response.ok) {
            throw new Error(`HTTP error! status: ${response.status}`);
        }
        const job = await response.json();
        
        document.getElementById('job-details').innerHTML = `
            <h1>${job.job_title}</h1>
            <p>${job.job_description}</p>
            <p>Requirements: ${job.job_requirements}</p>
            <p>Type: ${job.job_type}</p>
            <p>Salary: ${job.job_minSalary} - ${job.job_maxSalary}</p>
            <p>Education: ${job.job_education}</p>
            <p>Location: ${job.company_location}</p>
            <p>Company: ${job.company_name}</p>
        `;
    } catch (error) {
        console.error('Fetch error:', error);
        document.getElementById('job-details').innerHTML = 'Error loading job details.';
    }
});
