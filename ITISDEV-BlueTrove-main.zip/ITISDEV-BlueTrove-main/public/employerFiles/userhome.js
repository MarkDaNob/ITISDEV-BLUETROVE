document.addEventListener('DOMContentLoaded', async () => {

    // Fetch and display job listings
    try {
        const response = await fetch('/api/jobs');

        if (!response.ok) {
            throw new Error(`HTTP error! Status: ${response.status}`);
        }

        const jobs = await response.json();
        const jobList = document.getElementById('job-list');

        jobList.innerHTML = jobs.map(job => `
            <a href="/job-details.html?id=${job._id}" class="job-card">
                <div class="titlejob">${job.job_title}</div>
                <div class="detailsjob">
                    <div class="job-type">${job.job_type || 'N/A'}</div>
                    <span class="pay-job">Salary: ${job.job_minSalary} - ${job.job_maxSalary}</span>
                </div>
                <div class="company">
                    <img class="company-logo" src="${job.company_logo || '/employerFiles/default-logo.png'}" alt="Company Logo">
                    <div class="company-name">${job.company_name || 'Company Name'}</div>
                    <div class="company-location">
                        <img class="pin-icon" src="/employerFiles/pin.png" alt="Location Icon">
                        ${job.company_location || 'Location'}
                    </div>
                </div>
            </a>
        `).join('');
    } catch (error) {
        console.error('Error fetching job postings:', error);
    }

    // Function to fetch and display notifications
    async function fetchNotifications() {
        try {
            const response = await fetch('/api/notifications');
            const notifications = await response.json();
            console.log('Fetched notifications:', notifications); // Debugging log

            const notificationList = document.getElementById('notification-list');
            notificationList.innerHTML = ''; // Clear current notifications

            if (notifications.length === 0) {
                console.log("No notifications found");
                notificationList.innerHTML = "<li>No notifications available.</li>";
            }

            notifications.slice(-5).forEach(notification => {
                const li = document.createElement('li');
                li.innerHTML = `
                    <strong>${notification.message}</strong><br>
                    <span>${new Date(notification.date).toLocaleString()}</span>
                    ${notification.message !== 'Job Accepted!' ? `<button class="accept-btn" data-id="${notification._id}">Accept</button>` : ''}
                `;
                notificationList.appendChild(li);
            });

            // Add event listeners to all accept buttons
            document.querySelectorAll('.accept-btn').forEach(button => {
                button.addEventListener('click', async (e) => {
                    const notificationId = e.target.getAttribute('data-id');
                    await acceptNotification(notificationId);
                    // Remove the accept button after clicking
                    e.target.remove();
                });
            });

        } catch (error) {
            console.error('Error fetching notifications:', error);
        }
    }

    // Function to accept a notification and add "Job Accepted" notification
    async function acceptNotification(notificationId) {
        try {
            const response = await fetch(`/api/notifications/accept/${notificationId}`, {
                method: 'POST'
            });

            if (response.ok) {
                // Add a new "Job Accepted!" notification
                await fetch('/api/notifications/add', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json',
                    },
                    body: JSON.stringify({ message: 'Job Accepted!' }),
                });

                // Refresh notifications after acceptance and adding new notification
                fetchNotifications();
            } else {
                console.error('Error accepting notification:', response.statusText);
            }
        } catch (error) {
            console.error('Error accepting notification:', error);
        }
    }

    // Fetch notifications when the page loads
    fetchNotifications();
});
