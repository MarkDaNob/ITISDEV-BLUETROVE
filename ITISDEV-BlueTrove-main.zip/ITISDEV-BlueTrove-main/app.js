// npm i bcrypt body-parser express mongoose express-session connect-mongo
// node app.js

const express = require('express');
const session = require('express-session');
const MongoStore = require('connect-mongo');
const bodyParser = require('body-parser');
const mongoose = require('mongoose');
const bcrypt = require('bcrypt'); //hash password
const path = require('path');

const saltRounds = 10; // Number of hashing rounds
const port = process.env.PORT || 3000;

// Connect to MongoDB
const mongo_uri = 'mongodb://localhost:27017/blue_trove'; // Use your MongoDB URI here
mongoose.connect(mongo_uri);

// Middleware
const server = express();
server.use(express.json());
server.use(express.urlencoded({ extended: true }));
server.use(express.static(path.join(__dirname, 'public'))); // Use path.join to set the static folder

// Session setup
server.use(session({
    secret: 'your_secret_key', // Change this to a secure key
    resave: false,
    saveUninitialized: false,
    store: MongoStore.create({ mongoUrl: mongo_uri })
}));

// Define Mongoose Schemas and Models
const userSchema = new mongoose.Schema({
    user_email: { type: String, required: true },
    user_password: { type: String, required: true },
    user_name: { type: String, required: true },
    user_picture: { type: String },
    user_desc: { type: String },
    user_subscription: { type: Boolean, default: false },
    notifications: [{ message: String, date: { type: Date, default: Date.now } }]
}, { versionKey: false });

const userModel = mongoose.model('User', userSchema);
// Employer Schema
const employerSchema = new mongoose.Schema({
    employer_email: { type: String, required: true },
    employer_password: { type: String, required: true },
    employer_name: { type: String, required: true },
    employer_posts: [{ type: mongoose.Schema.Types.ObjectId, ref: 'Post' }]
}, { versionKey: false });

const employerModel = mongoose.model('Employer', employerSchema);

// Job Post Schema
const jobPostSchema = new mongoose.Schema({
    job_title: { type: String, required: true },
    job_description: { type: String, required: true },
    job_requirements: { type: String, required: true },
    job_type: { type: String, enum: ['Part-Time', 'Full-Time'], required: true },
    job_minSalary: { type: Number, required: true },
    job_maxSalary: { type: Number, required: true },
    job_education: { type: String, enum: ['High School', 'Associate Degree', 'Bachelor’s Degree', 'Master’s Degree', 'Doctorate Degree'], required: true },
    job_boosted: { type: Boolean, default: false },
    company_logo: { type: String, required: true },
    company_name: { type: String, required: true },
    company_location: { type: String, required: true },
    job_poster: { type: mongoose.Schema.Types.ObjectId, ref: 'Employer' },
    job_applicants: [{ type: mongoose.Schema.Types.ObjectId, ref: 'User' }]
}, { versionKey: false });

const postModel = mongoose.model('Post', jobPostSchema);

// Routes
server.get('/', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'employerFiles', 'homepage.html'));
});

// User sign-up route
server.post('/signup', async (req, res) => {
    const { name, email, password } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        const newUser = new userModel({
            user_name: name,
            user_email: email,
            user_password: hashedPassword,
        });

        await newUser.save();
        req.session.userId = newUser._id; // Save user ID in session
        res.redirect('/employerFiles/signin.html'); //go to user home

    } catch (error) {
        console.error('Error registering user:', error); // Log the detailed error
        res.status(500).json({ error: 'Error registering user' });
    }
});

// User sign-in route
server.post('/signin', async (req, res) => {
    const { email, password } = req.body;

    try {
        const user = await userModel.findOne({ user_email: email });

        if (!user) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        const isPasswordValid = await bcrypt.compare(password, user.user_password);

        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        req.session.userId = user._id; // Save user ID in session
        res.redirect('/employerFiles/userhome.html'); // Update this line
    } catch (error) {
        res.status(500).json({ error: 'Error signing in user' });
    }
});

// Employer sign-up route
server.post('/signup-employers', async (req, res) => {
    const { name, email, password } = req.body;

    try {
        const hashedPassword = await bcrypt.hash(password, saltRounds);

        const newEmployer = new employerModel({
            employer_name: name,
            employer_email: email,
            employer_password: hashedPassword,
        });

        await newEmployer.save();
        req.session.employerId = newEmployer._id; // Save employer ID in session
        res.redirect('/employerFiles/signin-employers.html'); // Redirect to employer sign-in page
        
    } catch (error) {
        console.error('Error details:', error); // Log the detailed error
        res.status(500).json({ error: 'Error registering employer' });
    }
});

// Define the employer home route
server.get('/employers', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'employerFiles', 'employers.html'));
});


// Employer sign-in route
server.post('/signin-employers', async (req, res) => {
    const { email, password } = req.body;

    try {
        const employer = await employerModel.findOne({ employer_email: email });

        if (!employer) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        const isPasswordValid = await bcrypt.compare(password, employer.employer_password);

        if (!isPasswordValid) {
            return res.status(401).json({ error: 'Invalid email or password' });
        }

        req.session.employerId = employer._id; // Save employer ID in session
        res.redirect('/employers'); //go to employer home // issue here

    } catch (error) {
        res.status(500).json({ error: 'Error signing in employer' });
    }
});

// New route for employer sign-in
server.get('/signin-employers.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'employerFiles', 'signin-employers.html'));
});

// Home page route
server.get('/userhome', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'employerFiles','userhome.html'));
});

// API route to get job postings
server.get('/api/jobs', async (req, res) => {
    try {
        const jobs = await postModel.find();
        res.json(jobs);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching job postings' });
    }
});

//Job details route, job offer details ito
server.get('/job-details.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'employerFiles', 'job-details.html'));
});

// API route to get a specific job by ID
server.get('/api/jobs/:id', async (req, res) => {
    try {
        const id = req.params.id;

        // Check if ID is a valid ObjectId
        if (mongoose.Types.ObjectId.isValid(id)) {
            // Query with ObjectId if it's a valid ObjectId format
            const job = await postModel.findById(id);

            if (!job) {
                return res.status(404).json({ error: `Job with ID ${id} not found` });
            }

            res.json(job);
        } else {
            // Query by string if it's not a valid ObjectId
            const job = await postModel.findOne({ _id: id });

            if (!job) {
                return res.status(404).json({ error: `Job with ID ${id} not found` });
            }

            res.json(job);
        }
    } catch (error) {
        console.error('Error fetching job details:', error);
        res.status(500).json({ error: 'Error fetching job details' });
    }
});

// Add this route to app.js
server.get('/api/current-user', async (req, res) => {
    if (req.session.userId) {
        try {
            const user = await userModel.findById(req.session.userId);
            if (user) {
                res.json({
                    _id: user._id,
                    name: user.user_name,
                    email: user.user_email,
                    description: user.user_desc,
                    picture: user.user_picture,
                    subscription: user.user_subscription
                });
            } else {
                res.status(404).json({ error: 'User not found' });
            }
        } catch (err) {
            res.status(500).json({ error: 'Error fetching user data' });
        }
    } else {
        res.status(401).json({ error: 'Not authenticated' });
    }
});

// Logout route
server.post('/logout', (req, res) => {
    req.session.destroy(err => {
        if (err) {
            return res.status(500).json({ error: 'Failed to log out' });
        }
        res.clearCookie('connect.sid'); // Clear the session cookie
        res.status(200).send();
    });
});

//Get user profile
server.get('/api/profile/:userId', async (req, res) => {
    try {
        const user = await userModel.findById(req.params.userId);
        if (!user) {
            return res.status(404).json({ message: 'User not found' });
        }
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

// Update user profile
server.post('/api/profile/:userId', async (req, res) => {
    try {
        const { user_email, user_password, user_name, user_picture, user_desc, user_subscription } = req.body;
        const user = await userModel.findByIdAndUpdate(
            req.params.userId,
            { user_email, user_password, user_name, user_picture, user_desc, user_subscription },
            { new: true, upsert: true }
        );
        res.json(user);
    } catch (error) {
        res.status(500).json({ message: 'Server error', error });
    }
});

// API route to get job postings for the currently logged-in employer
server.get('/api/employer-jobs', async (req, res) => {
    if (!req.session.employerId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
        const employer = await employerModel.findById(req.session.employerId).populate('employer_posts');
        if (!employer) {
            return res.status(404).json({ error: 'Employer not found' });
        }

        res.json(employer.employer_posts);
    } catch (error) {
        res.status(500).json({ error: 'Error fetching employer jobs' });
    }
});

// API route to handle job applications
server.post('/api/apply', async (req, res) => {
    const { jobId, userId } = req.body;

    if (!userId) {
        return res.status(401).json({ error: 'User not logged in' });
    }

    try {
        // Find the job post and add the user to the applicants list
        const job = await postModel.findById(jobId);

        if (!job) {
            return res.status(404).json({ error: 'Job not found' });
        }

        // Check if user is already an applicant
        if (job.job_applicants.includes(userId)) {
            return res.status(400).json({ error: 'User already applied for this job' });
        }

        job.job_applicants.push(userId);
        await job.save();

        res.json({ message: 'Application successful' });
    } catch (error) {
        console.error('Error applying for the job:', error);
        res.status(500).json({ error: 'Error applying for the job' });
    }
});

//Dynamic View Applicants Route
server.get('/viewapplicants.html', (req, res) => {
    res.sendFile(path.join(__dirname, 'public', 'employerFiles', 'viewapplicants.html'));
});

// Route to get applicants for a specific job
server.get('/api/jobs/:id/applicants', async (req, res) => {
    try {
        const job = await postModel.findById(req.params.id).populate('job_applicants');
        if (!job) {
            return res.status(404).json({ error: 'Job not found' });
        }
        const applicants = job.job_applicants.map(applicant => ({
            _id: applicant._id,
            name: applicant.user_name,
            picture: applicant.user_picture,
            appliedOn: applicant._id.getTimestamp(), // This gets the timestamp from the ObjectId
            status: 'inReview', // You might want to add a status field to your schema
            score: Math.floor(Math.random() * 100) // This is a placeholder, replace with actual score logic
        }));
        res.json(applicants);
    } catch (error) {
        console.error('Error fetching applicants:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Route to get details of a specific applicant
server.get('/api/applicants/:id', async (req, res) => {
    try {
        const applicant = await userModel.findById(req.params.id);
        if (!applicant) {
            return res.status(404).json({ error: 'Applicant not found' });
        }
        res.json(applicant);
    } catch (error) {
        console.error('Error fetching applicant details:', error);
        res.status(500).json({ error: 'Server error' });
    }
});
// Route to notify applicant of being hired or shortlisted using session
server.post('/notify-applicant', async (req, res) => {
    const { applicantId, status } = req.body;

    try {
        const applicant = await userModel.findById(applicantId);

        if (!applicant) {
            return res.status(404).json({ error: 'Applicant not found' });
        }

        const message = status === 'hired'
            ? 'You have been hired!'
            : 'You have been shortlisted!';

        // Add the new notification
        applicant.notifications.push({ 
            message, 
            date: new Date(),
            accepted: false // Add a flag to track if the notification has been accepted
        });

        // Keep only the 5 most recent notifications
        if (applicant.notifications.length > 5) {
            applicant.notifications = applicant.notifications.slice(-5);
        }

        await applicant.save();

        console.log("Final saved notifications:", applicant.notifications);

        res.json({ success: true, message: `Applicant has been ${status}` });
    } catch (error) {
        console.error('Error notifying applicant:', error);
        res.status(500).json({ error: 'Error notifying applicant' });
    }
});

// Route to get notifications for the current user from session
server.get('/api/notifications', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
        const user = await userModel.findById(req.session.userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        // Log notifications being sent to the client
        console.log("Notifications retrieved from DB:", user.notifications);

        res.json(user.notifications);
    } catch (error) {
        console.error('Error fetching notifications:', error);
        res.status(500).json({ error: 'Error fetching notifications' });
    }
});

// Route to mark notification as accepted
server.post('/api/notifications/accept/:id', async (req, res) => {
    try {
        const user = await userModel.findOneAndUpdate(
            { 'notifications._id': req.params.id },
            { $set: { 'notifications.$.accepted': true } },
            { new: true }
        );

        if (!user) {
            return res.status(404).json({ error: 'Notification not found' });
        }

        console.log("Notification accepted:", req.params.id);
        res.json({ success: true });
    } catch (error) {
        console.error('Error accepting notification:', error);
        res.status(500).json({ error: 'Error accepting notification' });
    }
});

// Route to check if the user is hired
server.get('/api/check-hire-status/:userId', async (req, res) => {
    try {
        const user = await userModel.findById(req.params.userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        const isHired = user.notifications.some(notification => notification.message === 'You have been hired!' && notification.accepted);
        res.json({ isHired });
    } catch (error) {
        console.error('Error checking hire status:', error);
        res.status(500).json({ error: 'Server error' });
    }
});

// Route to add a new notification for the current user
server.post('/api/notifications/add', async (req, res) => {
    if (!req.session.userId) {
        return res.status(401).json({ error: 'Not authenticated' });
    }

    try {
        const user = await userModel.findById(req.session.userId);

        if (!user) {
            return res.status(404).json({ error: 'User not found' });
        }

        const { message } = req.body;

        // Add the new notification
        user.notifications.push({
            message,
            date: new Date()
        });

        // Keep only the 5 most recent notifications
        if (user.notifications.length > 5) {
            user.notifications = user.notifications.slice(-5);
        }

        await user.save();

        res.json({ success: true, message: 'Notification added' });
    } catch (error) {
        console.error('Error adding notification:', error);
        res.status(500).json({ error: 'Error adding notification' });
    }
});

// Start the server
server.listen(port, () => {
    console.log('Listening at port ' + port);
});
