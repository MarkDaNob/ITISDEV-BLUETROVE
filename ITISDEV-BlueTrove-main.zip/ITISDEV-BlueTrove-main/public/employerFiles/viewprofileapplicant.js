document.addEventListener('DOMContentLoaded', async () => {
    const urlParams = new URLSearchParams(window.location.search);
    const userId = urlParams.get('id');

    if (!userId) {
        document.querySelector('.profile-content').innerHTML = 'User ID is missing.';
        return;
    }

    try {
        const response = await fetch(`/api/profile/${userId}`);
        if (!response.ok) {
            throw new Error('Failed to fetch user details');
        }
        const user = await response.json();

        document.getElementById('profile-header').innerHTML = `
            <img src="${user.user_picture || '/employerFiles/profilepic.png'}" alt="Profile Picture">
            <div class="profile-info">
                <h2>${user.user_name}</h2>
                <p>${user.user_email}</p>
            </div>
        `;
        document.getElementById('about-text').textContent = user.user_desc || 'No details available.';
        document.getElementById('subscription-status').textContent = user.user_subscription ? 'Subscribed' : 'Not Subscribed';

        // Check if the user has accepted a notification
        const acceptedNotification = user.notifications.find(n => n.accepted);
        if (acceptedNotification) {
            document.querySelector('.hire').textContent = 'Applicant Hired';
            document.querySelector('.hire').disabled = true;
        }

    } catch (error) {
        console.error('Error fetching user details:', error);
        document.querySelector('.profile-content').innerHTML = 'Error loading user details.';
    }
});
